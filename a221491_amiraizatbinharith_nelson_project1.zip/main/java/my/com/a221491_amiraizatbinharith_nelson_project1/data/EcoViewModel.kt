package my.com.a221491_amiraizatbinharith_nelson_project1.data

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

// ─────────────────────────────────────────────────────────────────────────────
// TopicState  — one entry per energy topic
// ─────────────────────────────────────────────────────────────────────────────
data class TopicState(
    val topicIndex       : Int,
    val chaptersCompleted: Int           = 0,
    val totalChapters    : Int           = 4,
    val quizScores       : List<Boolean?> = List(4) { null }
) {
    val progress: Float
        get() = if (totalChapters == 0) 0f
        else chaptersCompleted.toFloat() / totalChapters.toFloat()

    val completed: Boolean get() = chaptersCompleted >= totalChapters
}

// ─────────────────────────────────────────────────────────────────────────────
// EcoViewModel
// ─────────────────────────────────────────────────────────────────────────────
class EcoViewModel : ViewModel() {

    private val _topics = MutableStateFlow(
        listOf(
            TopicState(topicIndex = 0),
            TopicState(topicIndex = 1),
            TopicState(topicIndex = 2),
            TopicState(topicIndex = 3),
        )
    )
    val topics: StateFlow<List<TopicState>> = _topics.asStateFlow()

    fun markChapterComplete(
        topicIndex       : Int,
        chapterIndex     : Int,
        answeredCorrectly: Boolean
    ) {
        _topics.update { list ->
            list.mapIndexed { idx, state ->
                if (idx != topicIndex) return@mapIndexed state
                val scores    = state.quizScores.toMutableList()
                    .also { it[chapterIndex] = answeredCorrectly }
                val completed = scores.count { it == true }
                state.copy(chaptersCompleted = completed, quizScores = scores)
            }
        }
    }

    /** Reset a wrong quiz answer so the user can try again. */
    fun resetChapterQuiz(topicIndex: Int, chapterIndex: Int) {
        _topics.update { list ->
            list.mapIndexed { idx, state ->
                if (idx != topicIndex) return@mapIndexed state
                val scores = state.quizScores.toMutableList()
                    .also { it[chapterIndex] = null }
                val completed = scores.count { it == true }
                state.copy(chaptersCompleted = completed, quizScores = scores)
            }
        }
    }
}