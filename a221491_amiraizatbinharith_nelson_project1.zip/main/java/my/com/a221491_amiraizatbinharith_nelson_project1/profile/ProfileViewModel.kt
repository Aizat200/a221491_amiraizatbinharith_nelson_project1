package my.com.a221491_amiraizatbinharith_nelson_project1.profile

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

// ── Data class ───────────────────────────────────────────────────────────────
data class UserProfile(
    val name: String = "Amir Aizat",
    val email: String = "amir@ecoedu.my",
    val university: String = "Universiti Kebangsaan Malaysia",
    val course: String = "Bachelor of Software Engineering",
    val bio: String = "Passionate about renewable energy and sustainable technology.",
    val level: String = "Intermediate Learner",
    val joinDate: String = "April 2026"
)

// ── ViewModel ────────────────────────────────────────────────────────────────
class ProfileViewModel : ViewModel() {

    private val _profile = MutableStateFlow(UserProfile())
    val profile: StateFlow<UserProfile> = _profile

    fun updateProfile(updated: UserProfile) {
        _profile.value = updated
    }
}