package my.com.a221491_amiraizatbinharith_nelson_project1.profile

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import my.com.a221491_amiraizatbinharith_nelson_project1.data.EcoViewModel
import my.com.a221491_amiraizatbinharith_nelson_project1.home.AmberSurface
import my.com.a221491_amiraizatbinharith_nelson_project1.home.BlueSurface
import my.com.a221491_amiraizatbinharith_nelson_project1.home.BorderColor
import my.com.a221491_amiraizatbinharith_nelson_project1.home.CardBg
import my.com.a221491_amiraizatbinharith_nelson_project1.home.GreenLight
import my.com.a221491_amiraizatbinharith_nelson_project1.home.GreenPrimary
import my.com.a221491_amiraizatbinharith_nelson_project1.home.GreenSurface
import my.com.a221491_amiraizatbinharith_nelson_project1.home.RedSurface
import my.com.a221491_amiraizatbinharith_nelson_project1.home.TextPrimary
import my.com.a221491_amiraizatbinharith_nelson_project1.home.TextSecondary

// ── Profile Screen ───────────────────────────────────────────────────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    modifier: Modifier = Modifier,
    profileVm: ProfileViewModel = viewModel(),
    ecoVm: EcoViewModel = viewModel(),
    onEditProfile: () -> Unit = {}
) {
    val profile by profileVm.profile.collectAsStateWithLifecycle()
    val topics  by ecoVm.topics.collectAsStateWithLifecycle()

    val completedCount = topics.count { it.completed }
    val averageProgress = if (topics.isEmpty()) 0f
    else topics.sumOf { it.progress.toDouble() }.toFloat() / topics.size

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        // ── Hero banner ──────────────────────────────────────────────────────
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(GreenPrimary)
                .padding(horizontal = 20.dp)
                .padding(top = 48.dp, bottom = 32.dp)
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()) {

                // Avatar circle with initials
                Box(
                    modifier = Modifier
                        .size(84.dp)
                        .shadow(8.dp, CircleShape)
                        .clip(CircleShape)
                        .background(GreenLight),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = profile.name
                            .split(" ")
                            .take(2)
                            .joinToString("") { it.first().uppercase() },
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                Spacer(Modifier.height(14.dp))

                Text(
                    text = profile.name,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                Spacer(Modifier.height(4.dp))

                // Level badge
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(99.dp))
                        .background(Color.White.copy(alpha = 0.20f))
                        .padding(horizontal = 14.dp, vertical = 5.dp)
                ) {
                    Text(
                        text = "🌱  ${profile.level}",
                        fontSize = 12.sp,
                        color = GreenSurface
                    )
                }

                Spacer(Modifier.height(16.dp))

                // Edit Profile button
                OutlinedButton(
                    onClick = onEditProfile,
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = Color.White
                    ),
                    border = BorderStroke(
                        width = 1.dp,
                        color = Color.White.copy(alpha = 0.7f)
                    )
                ) {
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = null,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text("Edit Profile", fontSize = 13.sp)
                }
            }
        }

        Spacer(Modifier.height(20.dp))

        // ── Learning stats row ────────────────────────────────────────────────
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            StatChip(
                modifier = Modifier.weight(1f),
                emoji = "📚",
                value = "${topics.size}",
                label = "Topics",
                bg = AmberSurface
            )
            StatChip(
                modifier = Modifier.weight(1f),
                emoji = "✅",
                value = "$completedCount",
                label = "Done",
                bg = GreenSurface
            )
            StatChip(
                modifier = Modifier.weight(1f),
                emoji = "📈",
                value = "${(averageProgress * 100).toInt()}%",
                label = "Avg",
                bg = BlueSurface
            )
        }

        Spacer(Modifier.height(20.dp))

        // ── About section ─────────────────────────────────────────────────────
        SectionLabel(text = "ABOUT")

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = CardBg),
            elevation = CardDefaults.cardElevation(2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)) {

                ProfileRow(
                    icon = Icons.Default.Email,
                    iconBg = BlueSurface,
                    iconTint = Color(0xFF3B82F6),
                    label = "Email",
                    value = profile.email
                )
                HorizontalDivider(color = BorderColor, thickness = 0.5.dp)
                ProfileRow(
                    icon = Icons.Default.School,
                    iconBg = AmberSurface,
                    iconTint = Color(0xFFF59E0B),
                    label = "University",
                    value = profile.university
                )
                HorizontalDivider(color = BorderColor, thickness = 0.5.dp)
                ProfileRow(
                    icon = Icons.Default.Book,
                    iconBg = RedSurface,
                    iconTint = Color(0xFFEF4444),
                    label = "Course",
                    value = profile.course
                )
                HorizontalDivider(color = BorderColor, thickness = 0.5.dp)
                ProfileRow(
                    icon = Icons.Default.CalendarMonth,
                    iconBg = GreenSurface,
                    iconTint = GreenPrimary,
                    label = "Joined",
                    value = profile.joinDate
                )
            }
        }

        Spacer(Modifier.height(16.dp))

        // ── Bio section ───────────────────────────────────────────────────────
        SectionLabel(text = "BIO")

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = CardBg),
            elevation = CardDefaults.cardElevation(2.dp)
        ) {
            Text(
                text = profile.bio,
                fontSize = 14.sp,
                color = TextSecondary,
                lineHeight = 22.sp,
                modifier = Modifier.padding(16.dp)
            )
        }

        Spacer(Modifier.height(32.dp))
    }
}

// ── Helpers ──────────────────────────────────────────────────────────────────
@Composable
private fun SectionLabel(text: String) {
    Text(
        text = text,
        fontSize = 11.sp,
        fontWeight = FontWeight.Medium,
        color = TextSecondary,
        letterSpacing = 1.sp,
        modifier = Modifier
            .padding(horizontal = 20.dp)
            .padding(bottom = 8.dp)
    )
}

@Composable
private fun StatChip(
    modifier: Modifier = Modifier,
    emoji: String,
    value: String,
    label: String,
    bg: Color
) {
    Column(
        modifier = modifier
            .shadow(elevation = 3.dp, shape = RoundedCornerShape(14.dp))
            .clip(RoundedCornerShape(14.dp))
            .background(CardBg)
            .padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Box(
            modifier = Modifier
                .size(34.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(bg),
            contentAlignment = Alignment.Center
        ) {
            Text(text = emoji, fontSize = 16.sp)
        }
        Text(
            text = value,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
        )
        Text(
            text = label,
            fontSize = 11.sp,
            color = TextSecondary
        )
    }
}

@Composable
private fun ProfileRow(
    icon: ImageVector,
    iconBg: Color,
    iconTint: Color,
    label: String,
    value: String
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(iconBg),
            contentAlignment = Alignment.Center
        ) {
            Icon(imageVector = icon, contentDescription = null,
                tint = iconTint, modifier = Modifier.size(18.dp))
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(text = label, fontSize = 11.sp, color = TextSecondary)
            Text(text = value, fontSize = 14.sp, color = TextPrimary,
                fontWeight = FontWeight.Medium)
        }
    }
}


@Preview(showBackground = true, showSystemUi = true)
@Composable
fun ProfileScreenPreview() {
    ProfileScreen()
}