package my.com.a221491_amiraizatbinharith_nelson_project1

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import my.com.a221491_amiraizatbinharith_nelson_project1.calculator.CalculatorScreen
import my.com.a221491_amiraizatbinharith_nelson_project1.data.EcoViewModel
import my.com.a221491_amiraizatbinharith_nelson_project1.home.CardBg
import my.com.a221491_amiraizatbinharith_nelson_project1.home.GreenPrimary
import my.com.a221491_amiraizatbinharith_nelson_project1.home.HomeContent
import my.com.a221491_amiraizatbinharith_nelson_project1.home.SurfaceBg
import my.com.a221491_amiraizatbinharith_nelson_project1.home.TextSecondary
import my.com.a221491_amiraizatbinharith_nelson_project1.profile.EditProfileScreen
import my.com.a221491_amiraizatbinharith_nelson_project1.profile.ProfileScreen
import my.com.a221491_amiraizatbinharith_nelson_project1.profile.ProfileViewModel
import my.com.a221491_amiraizatbinharith_nelson_project1.progress.ProgressScreen
import my.com.a221491_amiraizatbinharith_nelson_project1.quiz.QuizScreen
import my.com.a221491_amiraizatbinharith_nelson_project1.topic.TopicScreen

// ── Routes ────────────────────────────────────────────────────────────────────
object Routes {

    const val HOME         = "home"
    const val PROGRESS     = "progress"
    const val CALCULATOR   = "calculator"
    const val QUIZ         = "quiz"
    const val PROFILE      = "profile"
    const val EDIT_PROFILE = "edit_profile"

    // topic route
    const val TOPIC = "topic/{topicIndex}"

    fun topicRoute(topicIndex: Int): String {
        return "topic/$topicIndex"
    }
}

// ── Root Navigation ───────────────────────────────────────────────────────────
@Composable
fun AppNavigation(
    ecoVm: EcoViewModel = viewModel(),
    profileVm: ProfileViewModel = viewModel()
) {

    val navController = rememberNavController()

    val currentEntry by navController.currentBackStackEntryAsState()

    val currentRoute = currentEntry?.destination?.route

    val bottomNavRoutes = setOf(
        Routes.HOME,
        Routes.PROGRESS,
        Routes.CALCULATOR,
        Routes.QUIZ,
        Routes.PROFILE
    )

    val showBottomBar = currentRoute in bottomNavRoutes

    Scaffold(
        containerColor = SurfaceBg,

        bottomBar = {

            if (showBottomBar) {

                AppBottomNavBar(
                    currentRoute = currentRoute,

                    onTabSelected = { route ->

                        navController.navigate(route) {

                            popUpTo(navController.graph.findStartDestination().id) {
                                saveState = true
                            }

                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                )
            }
        }

    ) { innerPadding ->

        NavHost(
            navController = navController,
            startDestination = Routes.HOME,
            modifier = Modifier.padding(innerPadding)
        ) {

            // ── HOME ─────────────────────────────────────────────────────────
            composable(Routes.HOME) {

                HomeContent(
                    vm = ecoVm,

                    onOpenTopic = { idx ->
                        navController.navigate(Routes.topicRoute(idx))
                    },

                    onOpenQuiz = {
                        navController.navigate(Routes.QUIZ)
                    }
                )
            }

            // ── PROGRESS ─────────────────────────────────────────────────────
            composable(Routes.PROGRESS) {

                ProgressScreen(
                    vm = ecoVm,

                    onOpenTopic = { idx ->
                        navController.navigate(Routes.topicRoute(idx))
                    }
                )
            }

            // ── CALCULATOR ──────────────────────────────────────────────────
            composable(Routes.CALCULATOR) {

                CalculatorScreen()
            }

            // ── QUIZ ────────────────────────────────────────────────────────
            composable(Routes.QUIZ) {

                QuizScreen(
                    vm = ecoVm,

                    onOpenTopic = { idx ->
                        navController.navigate(Routes.topicRoute(idx))
                    }
                )
            }

            // ── PROFILE ─────────────────────────────────────────────────────
            composable(Routes.PROFILE) {

                ProfileScreen(
                    profileVm = profileVm,
                    ecoVm = ecoVm,

                    onEditProfile = {
                        navController.navigate(Routes.EDIT_PROFILE)
                    }
                )
            }

            // ── EDIT PROFILE ────────────────────────────────────────────────
            composable(Routes.EDIT_PROFILE) {

                EditProfileScreen(
                    profileVm = profileVm,

                    onBack = {
                        navController.popBackStack()
                    }
                )
            }

            // ── TOPIC SCREEN ────────────────────────────────────────────────
            composable(Routes.TOPIC) { backStack ->

                val topicIndex =
                    backStack.arguments
                        ?.getString("topicIndex")
                        ?.toIntOrNull() ?: 0

                TopicScreen(
                    topicIndex = topicIndex,
                    vm = ecoVm,

                    onBack = {
                        navController.popBackStack()
                    }
                )
            }
        }
    }
}

// ── Bottom Navigation Bar ─────────────────────────────────────────────────────
@Composable
fun AppBottomNavBar(
    currentRoute: String?,
    onTabSelected: (String) -> Unit
) {

    NavigationBar(
        containerColor = CardBg,
        tonalElevation = 0.dp
    ) {

        val tabs = listOf(

            Triple(Icons.Default.Home, "Home", Routes.HOME),

            Triple(
                Icons.Default.DateRange,
                "Progress",
                Routes.PROGRESS
            ),

            Triple(
                Icons.Default.Calculate,
                "Calc",
                Routes.CALCULATOR
            ),

            Triple(Icons.Default.Star, "Quiz", Routes.QUIZ),

            Triple(Icons.Default.Person, "Profile", Routes.PROFILE)
        )

        tabs.forEach { (icon, label, route) ->

            NavigationBarItem(

                selected = currentRoute == route,

                onClick = {
                    onTabSelected(route)
                },

                icon = {
                    Icon(
                        imageVector = icon,
                        contentDescription = label
                    )
                },

                label = {
                    Text(
                        text = label,
                        fontSize = 10.sp
                    )
                },

                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = GreenPrimary,
                    selectedTextColor = GreenPrimary,
                    unselectedIconColor = TextSecondary,
                    unselectedTextColor = TextSecondary,
                    indicatorColor = Color.Transparent
                )
            )
        }
    }
}